import React from 'react';
import {
    Box, Typography, Button, Grid,
    Paper, Card, CardActionArea, CardMedia, CardContent
} from '@mui/material';
import { useProducts } from '../ProductContext';
import '../Styles/HomePage.css'

const selectedIDs = [36, 99, 100, 98, 97];

const HomePage = () => {
    const { products } = useProducts();
    const heroProductImage = products.find(product => product.id === selectedIDs[0]).image;
    return (
        <Box className='homepage-container'>
            {/** Hero Section */}
            <Box className='hero-section' style={{ backgroundImage: `url(${heroProductImage})` }}>
                <CardMedia className='hero-image'
                    component="img"
                    alt="Hero Image"
                    height="YOUR DESIRED HEIGHT"  // e.g., "400"
                    image={heroProductImage}
                />
                <Typography variant='h2' className='hero-title'>cuck</Typography>
                <Typography variant='h6' className='hero-subtitle'>cock</Typography>
                <Box className='hero-button'>
                    <Button variant='contained' color='primary'>cack</Button>
                </Box>
            </Box>

            {/** Featured Product */}
            <Paper className='featured-products'>
                <Typography variant='h4' gutterBottom>
                    Featured Products
                </Typography>
                <Grid container spacing={4}>
                    <Grid item>
                        <Card>
                            {/** Option 1: Crab - cute 
                             * Option 2: Cabin in Forest
                             * Option 3: Fairy Town
                             * Option 4: Beautiful Pond View
                            */}
                            <CardActionArea>
                                <CardMedia
                                    component='img'
                                    image=''
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="div">
                                        Product Name
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Product Description
                                    </Typography>
                                </CardContent>
                            </CardActionArea>
                        </Card>
                    </Grid>
                </Grid>
            </Paper>

            {/** About Section */}
        </Box>
    )
}

export default HomePage;